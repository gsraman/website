# website
A responsive layout  for college website
